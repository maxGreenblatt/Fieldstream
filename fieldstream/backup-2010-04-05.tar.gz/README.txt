privacy.py: main source code for processing privacy
privparser.py: parser for json objects.

