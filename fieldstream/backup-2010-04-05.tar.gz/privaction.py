
def do_privacy_actions(requestor, rules, waveseg_list):
	return waveseg_list

